<template>
  <div class="container">
    <Cabecera
      :pendientes="pendientes"
      :total="total"
      @addTask="addTask"
      @clearTasks="clearCompleted"
    />
    <!-- Pasamos las tareas ordenadas -->
    <ListaTareas
      :tasks="sortedTasks"
      @toggleStatus="toggleStatus"
      @deleteTask="deleteTask"
      @updatePriority="updatePriority"
    />
    <Pie />
  </div>
</template>

<script setup>
import { ref, computed } from "vue";
import Cabecera from "./components/Cabecera.vue";
import ListaTareas from "./components/listaTareas.vue";
import Pie from "./components/Pie.vue";
import { useFirestore } from 'vuefire';
import { useCollection } from 'vuefire';
import { collection } from 'firebase/firestore';


const db = useFirestore();

const tasks = useCollection(collection(db, 'lista'));


const pendientes = computed(() =>
  tasks.value.filter((task) => !task.completed).length
);
const total = computed(() => tasks.value.length);

const priorityOrder = { high: 1, normal: 2, low: 3 };


const sortedTasks = computed(() => {
  return [...tasks.value].sort(
    (a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]
  );
});

const addTask = (newTask) => {
  tasks.value.push(newTask);
  saveTasks();
};

const toggleStatus = (index) => {
  tasks.value[index].completed = !tasks.value[index].completed;
  saveTasks();
};

const deleteTask = (index) => {
  tasks.value.splice(index, 1);
  saveTasks();
};

const updatePriority = (index, priority) => {
  tasks.value[index].priority = priority;
  saveTasks();
};

const clearCompleted = () => {
  tasks.value = tasks.value.filter((task) => !task.completed);
  saveTasks();
};

const saveTasks = () => {
  localStorage.setItem("tasks", JSON.stringify(tasks.value));
};

const loadTasks = () => {
  const savedTasks = localStorage.getItem("tasks");
  if (savedTasks) {
    tasks.value = JSON.parse(savedTasks);
  }
};

loadTasks(); 
</script>

<style scoped>
.container {
  background-color: #1e1e1e;
  color: #ffffff;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
}
</style>
