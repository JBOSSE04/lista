<template>
  <li :class="['task-item', { completed: task.completed }]">
    <div class="task-header">
      <button class="status-btn" @click="$emit('toggleStatus')">
        {{ task.completed ? "✅" : "⭕" }}
      </button>
      <span class="task-text">{{ task.text }}</span>
      <button class="delete-btn" @click="$emit('deleteTask')">❌</button>
    </div>
    <div class="task-footer">
      <div class="priority-buttons">
        <button
          :class="{ active: task.priority === 'low' }"
          @click="$emit('updatePriority', 'low')"
        >
          🟢 Low
        </button>
        <button
          :class="{ active: task.priority === 'normal' }"
          @click="$emit('updatePriority', 'normal')"
        >
          🟡 Normal
        </button>
        <button
          :class="{ active: task.priority === 'high' }"
          @click="$emit('updatePriority', 'high')"
        >
          🔴 High
        </button>
      </div>
      <span class="added-time">Añadido hace {{ timeAgo }}</span>
    </div>
  </li>
</template>


<script setup>
import { defineProps, computed, ref, onMounted, onUnmounted } from "vue";

const props = defineProps({
  task: {
    type: Object,
    required: true,
  },
});

const timeAgo = ref("");

const calculateTimeAgo = () => {
  if (!props.task.createdAt) {
    timeAgo.value = "desconocido";
    return;
  }

  const now = new Date();
  const created = new Date(props.task.createdAt);
  const diffMs = now - created;
  const diffMinutes = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMinutes / 60);

  if (diffMinutes < 1) {
    timeAgo.value = "menos de un minuto";
  } else if (diffMinutes < 60) {
    timeAgo.value = `${diffMinutes} minuto${diffMinutes === 1 ? "" : "s"}`;
  } else if (diffHours < 24) {
    timeAgo.value = `${diffHours} hora${diffHours === 1 ? "" : "s"}`;
  } else {
    const diffDays = Math.floor(diffHours / 24);
    timeAgo.value = `${diffDays} día${diffDays === 1 ? "" : "s"}`;
  }
};

let intervalId;
onMounted(() => {
  calculateTimeAgo(); 
  intervalId = setInterval(calculateTimeAgo, 60000); 
});

onUnmounted(() => {
  clearInterval(intervalId); 
});
</script>


<style scoped>
.task-item {
  display: flex;
  flex-direction: column;
  padding: 10px;
  margin-bottom: 10px;
  background-color: #2e2e2e;
  border-radius: 4px;
}

.task-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.task-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 10px;
}

.priority-buttons button {
  margin-right: 5px;
  padding: 5px 10px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.priority-buttons button.active {
  font-weight: bold;
  color: #2e2e2e;
  background-color: rgb(201, 201, 201);
}

.priority-buttons button:nth-child(1) {
  color: #000000;
}

.priority-buttons button:nth-child(2) {
  color: #000000;
}

.priority-buttons button:nth-child(3) {
  color: #000000;
}

.added-time {
  color: #aaa;
  font-size: 0.9em;
}

.status-btn,
.delete-btn {
  background: none;
  border: none;
  cursor: pointer;
  color: #ffffff;
}

.delete-btn {
  color: #ff4500;
}
</style>
