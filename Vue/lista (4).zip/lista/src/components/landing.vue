<template>
    <div class="landing-container">
      <!-- Sección principal -->
      <header class="landing-header">
        <h1 class="landing-title">¡Bienvenido a Gestor de Tareas!</h1>
        <p class="landing-subtitle">
          Organiza tu vida de forma sencilla y eficiente. Empieza ahora.
        </p>
        <button class="cta-button" @click="navigateToApp">Comenzar</button>
      </header>
  
    </div>
  </template>
  
  <script setup>
  import { useRouter } from "vue-router";
  const router = useRouter();
  
  function navigateToApp() {
    router.push("/recordatorios"); 
  }
  </script>
  
  <style scoped>
  body {
    font-family: "Arial", sans-serif;
    margin: 0;
    padding: 0;
    background-color: #f4f4f9;
    color: #333;
    
  }
  
  /* Contenedor principal */
  .landing-container {
    text-align: center;
    padding: 0 20px;
  }
  
  /* Encabezado */
  .landing-header {
    background: linear-gradient(135deg, #002efc, #7243ca);
    color: #fff;
    padding: 60px 20px;
    border-radius: 8px;
    margin-bottom: 40px;
  }
  
  .landing-title {
    font-size: 2.5rem;
    margin-bottom: 10px;
  }
  
  .landing-subtitle {
    font-size: 1.2rem;
    margin-bottom: 20px;
  }
  
  .cta-button {
    background-color: #fc5959;
    color: #fff;
    padding: 10px 20px;
    border: none;
    border-radius: 5px;
    font-size: 1rem;
    cursor: pointer;
    transition: background-color 0.3s ease;
  }
  
  .cta-button:hover {
    background-color: #ff5252;
  }
  
  
  </style>
  