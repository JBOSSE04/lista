<!-- REVISAR FUNCIONES -->

<template>
  <div class="container">

    <Cabecera
      :pendientes="pendientes"
      :total="total"
      @addTask="addTask"
      @clearTasks="clearCompleted"
    />
    <!-- Pasamos las tareas ordenadas -->
    <ListaTareas
      :tasks="tasks"
      @toggleStatus="toggleStatus"
      @deleteTask="deleteTask"
      @updatePriority="updatePriority"
    />
    <Pie />
  </div>
</template>

<script setup>

import { ref, computed } from "vue";
import Cabecera from "./Cabecera.vue";
import ListaTareas from "./listaTareas.vue";
import Pie from "./Pie.vue";
import { useFirestore, useCollection } from 'vuefire';    
import { collection, getFirestore, where } from 'firebase/firestore';
import { query,orderBy } from "firebase/firestore";
import { doc, updateDoc, deleteDoc, addDoc } from "firebase/firestore"; // funciones necesarias de Firestore


let db = useFirestore();
db = getFirestore();

// colección ordenada por prioridad
const tasks = useCollection(query(collection(db, 'lista'),orderBy('priority')));
const rocordarioREF = collection(db, 'lista')

// agregar una nueva tarea                                 where('idUsuario', "=="), 
async function addTask(title) {
  const newTask = {
    text: title.text,
    completed: false,
    priority: "normal",
    timeAgo: Date.now(),
  };

  try {
    const docRef = await addDoc(collection(db, "lista"), newTask);
    console.log("Documento agregado con ID: ", docRef.id);
  } catch (error) {
    console.error("Error al agregar tarea: ", error);
  }
}

// Cambiar el estado de completado de una tarea
async function toggleStatus(task) {
  try {
    if (!task || !task.id) throw new Error("Tarea inválida");
    const taskDoc = doc(db, "lista", task.id);
    await updateDoc(taskDoc, { completed: !task.completed });
    console.log(`Estado de la tarea '${task.text}' actualizado a: ${!task.completed}`);
  } catch (error) {
    console.error("Error al actualizar el estado de la tarea: ", error);
  }
}

// Eliminar una tarea
async function deleteTask(task) {
  try {
    if (!task || !task.id) throw new Error("Tarea inválida");
    const taskDoc = doc(db, "lista", task.id);
    await deleteDoc(taskDoc);
    console.log(`Tarea '${task.text}' eliminada.`);
  } catch (error) {
    console.error("Error al eliminar la tarea: ", error);
  }
}

// Actualizar la prioridad de una tarea
async function updatePriority(task, priority) {
  try {
    if (!task || !task.id) throw new Error("Tarea inválida");
    if (!priority) throw new Error("Prioridad no válida");
    const taskDoc = doc(db, "lista", task.id);
    await updateDoc(taskDoc, { priority });
    console.log(`Prioridad de la tarea '${task.text}' actualizada a: ${priority}`);
  } catch (error) {
    console.error("Error al actualizar la prioridad de la tarea: ", error);
  }
}

// Limpiar tareas completadas
async function clearCompleted(tasks) {
  try {
    if (!tasks || !tasks.length) throw new Error("No hay tareas para procesar");
    const completedTasks = tasks.filter((task) => task.completed);
    for (const task of completedTasks) {
      const taskDoc = doc(db, "lista", task.id);
      await deleteDoc(taskDoc);
    }
    console.log("Todas las tareas completadas han sido eliminadas.");
  } catch (error) {
    console.error("Error al eliminar tareas completadas: ", error);
  }
}

// Computos para pendientes y total (usando Vue.js o frameworks similares)
const pendientes = computed(() =>
  tasks.value.filter((task) => !task.completed).length
);
const total = computed(() => tasks.value.length);

</script>

<style scoped>
.container {
  background-color: #1e1e1e;
  color: #ffffff;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
}
</style>
