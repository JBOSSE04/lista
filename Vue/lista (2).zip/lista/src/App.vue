<template>
      <Login />

  <nav>
    <RouterLink to="/">Inicio</RouterLink>
    <RouterLink to="/recordatorios">Lista recordatorios</RouterLink>

  </nav>
<RouterView></RouterView>
</template>

<script setup>
import { useRouter} from 'vue-router'
import { getCurrentUser } from 'vuefire';
import Login from './components/Login.vue'

const router = useRouter();

router.beforeEach(async(to, from) => {
  // ...
  // explicitly return false to cancel the navigation

  if (to.meta.requiresAuth)
{
  const user = await getCurrentUser()
    if(!user){
      router.push('/')
      return false;
    }else
      return true;
    
}
 
 else 
 {
  return true
 }
})




</script>

<style scoped>

</style>
