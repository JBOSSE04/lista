<template>
  <p v-if="user">Hello {{ user.displayName }}</p>
  <button v-if="user"@click="cerrarSesion">Cerrar Sesion</button>
  <button v-else @click="IniciarSesion">Iniciar Sesion</button>

</template>


<script setup>

import { GoogleAuthProvider } from 'firebase/auth'
const googleAuthProvider = new GoogleAuthProvider()
import {
  signInWithPopup,
  signOut,
} from 'firebase/auth'
import { useCurrentUser, useFirebaseAuth } from 'vuefire'
import { useRouter } from 'vue-router'

const router = useRouter();
const auth = useFirebaseAuth();
const user = useCurrentUser();

function IniciarSesion() {
    signInWithPopup(auth, googleAuthProvider).then(
        ()=>console.log("validacion correcta"),
    ).catch((reason) => {
    console.error('Failed sign', reason)

})

}

function cerrarSesion() {
    signOut(auth).then(
        () => {console.log('Sesion cerrada correctamente');
        router.push('/');

    }).catch(
        (error) => {console.error('Error al cerrar la sesion', error);
    });
    }

</script>



<style scoped>

</style>