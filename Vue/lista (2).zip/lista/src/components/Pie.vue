<template>
  <footer>
    <p>
    <strong>JJCM</strong><br />
    </p>
  </footer>
</template>

<script setup></script>

<style scoped>
footer {
  text-align: center;
  margin-top: 20px;
  color: #ddd;
}

a {
  color: #00d1b2;
  text-decoration: none;
}
</style>
