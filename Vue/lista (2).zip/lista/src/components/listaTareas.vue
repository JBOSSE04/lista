<template>
  <ul class="task-list">
    <Tarea
      v-for="(task, index) in tasks"
      :key="index"
      :task="task"
      @toggleStatus="$emit('toggleStatus', index)"
      @deleteTask="$emit('deleteTask', index)"
      @updatePriority="$emit('updatePriority', index, $event)"
    />
  </ul>
</template>

<script setup>
import { defineProps } from "vue";
import Tarea from "./tarea.vue";

const props = defineProps({
  tasks: Array,
});
</script>

<style scoped>
.task-list {
  margin-top: 20px;
  list-style: none;
  padding: 0;
}
</style>
