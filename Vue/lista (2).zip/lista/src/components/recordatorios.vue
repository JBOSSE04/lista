<!-- REVISAR FUNCIONES -->

<template>
  <div class="container">

    <Cabecera
      :pendientes="pendientes"
      :total="total"
      @addTask="addTask"
      @clearTasks="clearCompleted"
    />
    <!-- Pasamos las tareas ordenadas -->
    <ListaTareas
      :tasks="tasks"
      @toggleStatus="toggleStatus"
      @deleteTask="deleteTask"
      @updatePriority="updatePriority"
    />
    <Pie />
  </div>
</template>

<script setup>

import { ref, computed } from "vue";
import Cabecera from ".//Cabecera.vue";
import ListaTareas from ".//listaTareas.vue";
import Pie from ".//Pie.vue";
import { useFirestore, useCollection } from 'vuefire';    
import { collection } from 'firebase/firestore';
import { addDoc,query,orderBy } from "firebase/firestore";


const db = useFirestore();

// colección ordenada por prioridad
const tasks = useCollection(query(collection(db, 'lista'), orderBy('priority')));

// agregar una nueva tarea
async function addTask(title) {
  const newTask = {
    text: title.text,
    completed: false,
    priority: "normal",
    timeAgo: Date.now(),
  };

  try {
    const docRef = await addDoc(collection(db, "lista"), newTask);
    console.log("Documento agregado con ID: ", docRef.id);
  } catch (error) {
    console.error("Error al agregar tarea: ", error);
  }
}

// cambiar el estado de completado de una tarea
async function toggleStatus(task) {
  try {
    const taskDoc = doc(db, "lista", task.id);
    await updateDoc(taskDoc, { completed: !task.completed });
    console.log("Estado de tarea actualizado.");
  } catch (error) {
    console.error("Error al actualizar estado de tarea: ", error);
  }
}

// eliminar una tarea
async function deleteTask(task) {
  try {
    const taskDoc = doc(db, "lista", task.id);
    await deleteDoc(taskDoc);
    console.log("Tarea eliminada.");
  } catch (error) {
    console.error("Error al eliminar tarea: ", error);
  }
}

// actualizar la prioridad de una tarea
async function updatePriority(task, priority) {
  try {
    const taskDoc = doc(db, "lista", task.id);
    await updateDoc(taskDoc, { priority });
    console.log("Prioridad de tarea actualizada.");
  } catch (error) {
    console.error("Error al actualizar prioridad de tarea: ", error);
  }
}

// limpiar tareas completadas
async function clearCompleted() {
  try {
    const completedTasks = tasks.value.filter((task) => task.completed);
    for (const task of completedTasks) {
      const taskDoc = doc(db, "lista", task.id);
      await deleteDoc(taskDoc);
    }
    console.log("Tareas completadas eliminadas.");
  } catch (error) {
    console.error("Error al eliminar tareas completadas: ", error);
  }
}

// computos para pendientes y total
const pendientes = computed(() =>
  tasks.value.filter((task) => !task.completed).length
);
const total = computed(() => tasks.value.length);

</script>

<style scoped>
.container {
  background-color: #1e1e1e;
  color: #ffffff;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
  border-radius: 8px;
  box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
}
</style>
