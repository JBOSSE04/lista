import React, { useState, useEffect } from 'react';
import PokemonCard from './PokemonCard';
import PokemonDetail from './PokemonDetail';

const PokemonList = () => {
  const [pokemonList, setPokemonList] = useState([]);
  const [selectedPokemon, setSelectedPokemon] = useState(null);
  const [nextUrl, setNextUrl] = useState('https://pokeapi.co/api/v2/pokemon?limit=8');

  const fetchPokemon = async (url) => {
    const response = await fetch(url);
    const data = await response.json();
    setNextUrl(data.next);

    const pokemonData = await Promise.all(data.results.map(async (pokemon) => {
      const response = await fetch(pokemon.url);
      return await response.json();
    }));
    setPokemonList((prevList) => [...prevList,...pokemonData]);

  };

  useEffect(() => {
    fetchPokemon(nextUrl);
  }, []);

  ///////////////////////////////////////
  

  ///////////////////////////////

  const handleLoadMore = () => {
    fetchPokemon(nextUrl);
  };

  const handleShowDetail = (pokemon) => {
    setSelectedPokemon(pokemon);
  };


  return (
    <div>
      <div className="pokemon-list">
        {pokemonList.map((pokemon) => (
          <PokemonCard key={pokemon.id} pokemon={pokemon} onShowDetail={handleShowDetail} />
        ))}
      </div>
      <button onClick={handleLoadMore}>Obtener más</button>
      {selectedPokemon && <PokemonDetail pokemon={selectedPokemon} />}
    </div>
  );
};

export default PokemonList;