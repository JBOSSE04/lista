import React from 'react';

const PokemonDetail = ({ pokemon }) => {
  if (!pokemon) return null;

  return (
    <div className="pokemon-detail">
      <h2>{pokemon.name}</h2>
      <img src={pokemon.sprites.front_default} alt={pokemon.name} />
      <p>Altura: {pokemon.height}</p>
      <p>Peso: {pokemon.weight}</p>
      <p>Tipos: {pokemon.types.map(type => type.type.name).join(', ')}</p>
      <p>Habilidades: {pokemon.abilities.map(ability => ability.ability.name).join(', ')}</p>
    </div>
  );
};

export default PokemonDetail;