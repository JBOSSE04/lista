import React from 'react';
import './LandingPage.css';

const LandingPage = ({ onExplore }) => {
  return (
    <div className="landing-page">
      <div className="landing-content">
        <h1>Bienvenido al Mundo Pokémon</h1>
        <p>
          Explora el fascinante mundo de los Pokémon. Descubre sus habilidades,
          tipos y características únicas. ¡Comienza tu aventura ahora!
        </p>
        <button onClick={onExplore}>Explorar Pokémon</button>
      </div>
    </div>
  );
};

export default LandingPage;