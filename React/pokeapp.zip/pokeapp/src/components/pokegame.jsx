import React, { useState, useEffect } from 'react';
import './LandingPage.css';

const PokemonGame = () => {
  const [pokemon, setPokemon] = useState(null);
  const [userGuess, setUserGuess] = useState('');
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [revealed, setRevealed] = useState(false); // Estado para controlar si la imagen está revelada

  // Función para obtener un Pokémon aleatorio
  const fetchRandomPokemon = async () => {
    setLoading(true);
    const randomId = Math.floor(Math.random() * 898) + 1; // Hay 898 Pokémon en la PokeAPI
    const response = await fetch(`https://pokeapi.co/api/v2/pokemon/${randomId}`);
    const data = await response.json();
    setPokemon(data);
    setLoading(false);
    setRevealed(false); // Reiniciar el estado de revelación
    setMessage(''); // Reiniciar el mensaje
    setUserGuess(''); // Reiniciar la entrada del usuario
  };

  useEffect(() => {
    fetchRandomPokemon();
  }, []);

  // Función para manejar el intento del usuario
  const handleGuess = () => {
    if (userGuess.toLowerCase() === pokemon.name.toLowerCase()) {
      setMessage(`¡Correcto! Es ${pokemon.name}.`);
      setRevealed(true); // Revelar la imagen
    } else {
      setMessage(`Incorrecto. Intenta de nuevo.`);
    }
  };

  if (loading) {
    return <p>Cargando Pokémon...</p>;
  }

  return (
    <div className="pokemon-game">
      <h2>Adivina el Pokémon</h2>
      <div className="pokemon-image-container">
        <img
          src={pokemon.sprites.other['official-artwork'].front_default}
          alt="Pokémon"
          className={`pokemon-image ${revealed ? 'revealed' : ''}`}
        />
      </div>
      <div className="clues">
        <p><strong>Tipo:</strong> {pokemon.types.map(type => type.type.name).join(', ')}</p>
        <p><strong>Altura:</strong> {pokemon.height / 10} m</p>
        <p><strong>Peso:</strong> {pokemon.weight / 10} kg</p>
        <p><strong>Habilidades:</strong> {pokemon.abilities.map(ability => ability.ability.name).join(', ')}</p>
      </div>
      <input
        type="text"
        placeholder="Ingresa el nombre del Pokémon"
        value={userGuess}
        onChange={(e) => setUserGuess(e.target.value)}
      />
      <button onClick={handleGuess}>Adivinar</button>
      {message && <p className="message">{message}</p>}
      <button onClick={fetchRandomPokemon}>Nuevo Pokémon</button>
    </div>
  );
};

export default PokemonGame;