import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import LandingPage from './components/LandingPage';
import PokemonList from './components/PokemonList';
import PokemonGame from './components/pokegame';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <nav>
          <Link to="/">Inicio</Link>
          <Link to="/pokemon">Pokémon</Link>
          <Link to="/jugar">Jugar</Link>
        </nav>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/pokemon" element={<PokemonList />} />
          <Route path="/jugar" element={<PokemonGame />} />
        </Routes>

        
      </div>
    </Router>
  );
}

export default App;